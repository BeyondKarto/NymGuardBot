﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

class Program
{
    private static ITelegramBotClient botClient = new TelegramBotClient("7202384152:AAEFjafaZe0XWsZ-h-4WmlJa3y-vvaKtxJA");
    private static Dictionary<long, int> userAttempts = new Dictionary<long, int>();
    private static Dictionary<long, string> correctAnswers = new Dictionary<long, string>();
    private static Dictionary<long, Timer> activeTimers = new Dictionary<long, Timer>();
    private static Dictionary<long, List<int>> messageIdsToDelete = new Dictionary<long, List<int>>();
    private static Dictionary<long, string> userLanguages = new Dictionary<long, string>();

    static async Task Main(string[] args)
    {
        var receiverOptions = new ReceiverOptions
        {
            AllowedUpdates = Array.Empty<UpdateType>() // Receive all update types
        };

        botClient.StartReceiving(HandleUpdateAsync, HandleErrorAsync, receiverOptions);

        Console.WriteLine("Bot is running...");
        await Task.Delay(-1);
    }

    private static async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
    {
        if (update.Type == UpdateType.Message && update.Message != null)
        {
            var message = update.Message;

            if (message.Type == MessageType.ChatMembersAdded)
            {
                foreach (var member in message.NewChatMembers)
                {
                    if (!member.IsBot)
                    {
                        await SendLanguageSelectionMessageAsync(message.Chat.Id, member);
                    }
                }
            }
        }
        else if (update.Type == UpdateType.CallbackQuery && update.CallbackQuery != null)
        {
            await HandleCallbackQueryAsync(update.CallbackQuery);
        }
    }

    private static async Task SendLanguageSelectionMessageAsync(long chatId, User user)
    {
        var languageOptions = new InlineKeyboardMarkup(new[]
        {
            new[] { InlineKeyboardButton.WithCallbackData("English", "en"), InlineKeyboardButton.WithCallbackData("Українська", "uk") },
            new[] { InlineKeyboardButton.WithCallbackData("Français", "fr"), InlineKeyboardButton.WithCallbackData("中文", "zh") }
        });

        var welcomeMessage = await botClient.SendTextMessageAsync(
            chatId: chatId,
            text: $"Hello, @{user.Username}! Please choose your language.",
            replyMarkup: languageOptions,
            disableNotification: true
        );

        if (!messageIdsToDelete.ContainsKey(user.Id))
        {
            messageIdsToDelete[user.Id] = new List<int>();
        }

        messageIdsToDelete[user.Id].Add(welcomeMessage.MessageId);
    }

    private static async Task HandleCallbackQueryAsync(CallbackQuery callbackQuery)
    {
        if (callbackQuery?.Data == null || callbackQuery.Message == null)
        {
            return;
        }

        long userId = callbackQuery.From.Id;

        if (userLanguages.ContainsKey(userId))
        {
            int userAnswerIndex;

            if (int.TryParse(callbackQuery.Data, out userAnswerIndex))
            {
                if (correctAnswers.TryGetValue(userId, out string correctAnswer))
                {
                    string feedbackText;
                    bool isCorrect = languageQuestions[userLanguages[userId]].Any(q => q.Options[userAnswerIndex] == correctAnswer);

                    if (isCorrect)
                    {
                        feedbackText = GetWelcomeMessageForPrivacy(userLanguages[userId]);
                        var feedbackMessage = await botClient.SendTextMessageAsync(
                            chatId: callbackQuery.Message.Chat.Id,
                            text: feedbackText,
                            disableNotification: true
                        );

                        if (!messageIdsToDelete.ContainsKey(userId))
                        {
                            messageIdsToDelete[userId] = new List<int>();
                        }
                        messageIdsToDelete[userId].Add(feedbackMessage.MessageId);

                        await Task.Delay(5000);
                        await DeleteMessagesAsync(callbackQuery.Message.Chat.Id, userId);
                    }
                    else
                    {
                        feedbackText = GetFeedbackText(userLanguages[userId], false);
                        var feedbackMessage = await botClient.SendTextMessageAsync(
                            chatId: callbackQuery.Message.Chat.Id,
                            text: feedbackText,
                            disableNotification: true
                        );

                        if (!messageIdsToDelete.ContainsKey(userId))
                        {
                            messageIdsToDelete[userId] = new List<int>();
                        }
                        messageIdsToDelete[userId].Add(feedbackMessage.MessageId);

                        await DeleteMessagesAsync(callbackQuery.Message.Chat.Id, userId);
                        await SendQuestionAsync(callbackQuery.Message.Chat.Id, userId);
                    }
                }
            }
        }
        else
        {
            userLanguages[userId] = callbackQuery.Data;
            await SendQuestionAsync(callbackQuery.Message.Chat.Id, userId);
        }
    }

    private static async Task SendQuestionAsync(long chatId, long userId)
    {
        var question = GetRandomQuestion(userLanguages[userId]);
        correctAnswers[userId] = question.CorrectAnswer;

        var inlineKeyboard = new InlineKeyboardMarkup(
            question.Options.Select((option, index) =>
                new[] { InlineKeyboardButton.WithCallbackData(option, index.ToString()) }
            ).ToArray()
        );

        var message = await botClient.SendTextMessageAsync(
            chatId: chatId,
            text: $"{question.Text}\n{GetFeedbackText(userLanguages[userId], true)}",
            replyMarkup: inlineKeyboard,
            disableNotification: true
        );

        if (!messageIdsToDelete.ContainsKey(userId))
        {
            messageIdsToDelete[userId] = new List<int>();
        }
        messageIdsToDelete[userId].Add(message.MessageId);

        var timer = new Timer(async state => await HandleTimeoutAsync(chatId, userId), null, TimeSpan.FromSeconds(30), Timeout.InfiniteTimeSpan);
        activeTimers[userId] = timer;
    }

    private static async Task HandleTimeoutAsync(long chatId, long userId)
    {
        if (activeTimers.ContainsKey(userId))
        {
            activeTimers[userId].Change(Timeout.Infinite, Timeout.Infinite);
            activeTimers.Remove(userId);
        }

        await DeleteMessagesAsync(chatId, userId);

        userAttempts[userId]++;

        if (userAttempts[userId] >= 3)
        {
            await botClient.BanChatMemberAsync(chatId, userId);
            await botClient.SendTextMessageAsync(
                chatId: chatId,
                text: "The user has been banned for incorrect answers.",
                disableNotification: true
            );
        }
        else
        {
            await botClient.SendTextMessageAsync(
                chatId: chatId,
                text: "You did not answer in time! This counts as a failed attempt.",
                disableNotification: true
            );
            await Task.Delay(2000);
            await SendQuestionAsync(chatId, userId);
        }
    }

    private static async Task DeleteMessagesAsync(long chatId, long userId)
    {
        if (activeTimers.ContainsKey(userId))
        {
            activeTimers[userId].Change(Timeout.Infinite, Timeout.Infinite);
            activeTimers.Remove(userId);
        }

        if (messageIdsToDelete.ContainsKey(userId) && messageIdsToDelete[userId].Any())
        {
            foreach (var messageId in messageIdsToDelete[userId])
            {
                await botClient.DeleteMessageAsync(chatId, messageId);
            }
            messageIdsToDelete.Remove(userId);
        }
    }

    private static string GetWelcomeMessageForPrivacy(string language)
    {
        switch (language)
        {
            case "en":
                return "Welcome to the Privacy community! We recommend using NYM VPN to protect your metadata and ensure freedom of speech.";
            case "uk":
                return "Вітаємо у спільноті Приватності! Рекомендуємо використовувати NYM VPN для захисту метаданих і забезпечення свободи слова.";
            case "fr":
                return "Bienvenue dans la communauté de la confidentialité! Nous vous recommandons d'utiliser NYM VPN pour protéger vos métadonnées et garantir la liberté d'expression.";
            case "zh":
                return "欢迎加入隐私社区！我们建议使用NYM VPN来保护您的元数据并确保言论自由。";
            default:
                return "Welcome!";
        }
    }

    private static string GetFeedbackText(string language, bool isQuestion)
    {
        switch (language)
        {
            case "en":
                return isQuestion ? "You have 30 seconds to choose the correct option." : "Incorrect answer! Try again.";
            case "uk":
                return isQuestion ? "У вас є 30 секунд на вибір правильної відповіді." : "Неправильна відповідь! Спробуйте ще раз.";
            case "fr":
                return isQuestion ? "Vous avez 30 secondes pour choisir la bonne réponse." : "Réponse incorrecte! Réessayez.";
            case "zh":
                return isQuestion ? "您有30秒钟选择正确的答案。" : "答案错误！再试一次。";
            default:
                return "Try again.";
        }
    }

    private static Question GetRandomQuestion(string language)
    {
        var random = new Random();
        return languageQuestions[language][random.Next(languageQuestions[language].Count)];
    }

    private static readonly Dictionary<string, List<Question>> languageQuestions = new Dictionary<string, List<Question>>
    {
        {
            "en", new List<Question>
            {
                new Question { Text = "What is the capital of France?", Options = new[] { "a) Berlin", "b) Madrid", "c) Paris", "d) Rome" }, CorrectAnswer = "c) Paris" },
                new Question { Text = "Which planet is known as the Red Planet?", Options = new[] { "a) Earth", "b) Mars", "c) Jupiter", "d) Venus" }, CorrectAnswer = "b) Mars" },
                new Question { Text = "What is the largest ocean on Earth?", Options = new[] { "a) Atlantic", "b) Pacific", "c) Indian", "d) Arctic" }, CorrectAnswer = "b) Pacific" },
                new Question { Text = "Which country is home to the kangaroo?", Options = new[] { "a) USA", "b) Brazil", "c) Australia", "d) China" }, CorrectAnswer = "c) Australia" },
                new Question { Text = "What is the smallest continent?", Options = new[] { "a) Asia", "b) Europe", "c) Australia", "d) Antarctica" }, CorrectAnswer = "c) Australia" }
            }
        },
        {
            "uk", new List<Question>
            {
                new Question { Text = "Яка столиця України?", Options = new[] { "a) Київ", "b) Львів", "c) Одеса", "d) Харків" }, CorrectAnswer = "a) Київ" },
                new Question { Text = "Яка найбільша річка в Україні?", Options = new[] { "a) Дніпро", "b) Дністер", "c) Південний Буг", "d) Тиса" }, CorrectAnswer = "a) Дніпро" },
                new Question { Text = "Який океан найбільший у світі?", Options = new[] { "a) Атлантичний", "b) Тихий", "c) Індійський", "d) Північний Льодовитий" }, CorrectAnswer = "b) Тихий" },
                new Question { Text = "Яке місто відоме як культурна столиця України?", Options = new[] { "a) Харків", "b) Львів", "c) Одеса", "d) Дніпро" }, CorrectAnswer = "b) Львів" },
                new Question { Text = "Яке найбільше озеро в Україні?", Options = new[] { "a) Ялпуг", "b) Світязь", "c) Синевир", "d) Куяльник" }, CorrectAnswer = "a) Ялпуг" }
            }
        },
        {
            "fr", new List<Question>
            {
                new Question { Text = "Quelle est la capitale de la France?", Options = new[] { "a) Paris", "b) Lyon", "c) Marseille", "d) Bordeaux" }, CorrectAnswer = "a) Paris" },
                new Question { Text = "Quelle est la plus grande montagne d'Europe?", Options = new[] { "a) Mont Blanc", "b) Mont Everest", "c) Mont Fuji", "d) Mont Kilimandjaro" }, CorrectAnswer = "a) Mont Blanc" },
                new Question { Text = "Quel est le plus grand pays d'Afrique?", Options = new[] { "a) Égypte", "b) Algérie", "c) Nigéria", "d) Afrique du Sud" }, CorrectAnswer = "b) Algérie" },
                new Question { Text = "Quelle est la capitale de l'Italie?", Options = new[] { "a) Rome", "b) Milan", "c) Naples", "d) Florence" }, CorrectAnswer = "a) Rome" },
                new Question { Text = "Quel pays est connu pour ses pyramides?", Options = new[] { "a) Grèce", "b) Égypte", "c) Inde", "d) Pérou" }, CorrectAnswer = "b) Égypte" }
            }
        },
        {
            "zh", new List<Question>
            {
                new Question { Text = "中国的首都是什么?", Options = new[] { "a) 上海", "b) 北京", "c) 广州", "d) 深圳" }, CorrectAnswer = "b) 北京" },
                new Question { Text = "哪一个是世界上最高的山?", Options = new[] { "a) 珠穆朗玛峰", "b) 乞力马扎罗山", "c) 富士山", "d) 白朗峰" }, CorrectAnswer = "a) 珠穆朗玛峰" },
                new Question { Text = "哪个国家的动物是袋鼠?", Options = new[] { "a) 美国", "b) 澳大利亚", "c) 中国", "d) 巴西" }, CorrectAnswer = "b) 澳大利亚" },
                new Question { Text = "中国的最大河流是哪条?", Options = new[] { "a) 黄河", "b) 长江", "c) 珠江", "d) 牡丹江" }, CorrectAnswer = "b) 长江" },
                new Question { Text = "哪一个国家以金字塔著名?", Options = new[] { "a) 希腊", "b) 埃及", "c) 印度", "d) 祕鲁" }, CorrectAnswer = "b) 埃及" }
            }
        }
    };

    private class Question
    {
        public string Text { get; set; } = string.Empty;
        public string[] Options { get; set; } = Array.Empty<string>();
        public string CorrectAnswer { get; set; } = string.Empty;
    }

    private static Task HandleErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
    {
        var errorMessage = exception switch
        {
            ApiRequestException apiRequestException => $"Telegram API Error:\n[{apiRequestException.ErrorCode}]\n{apiRequestException.Message}",
            _ => exception.ToString()
        };

        Console.WriteLine(errorMessage);
        return Task.CompletedTask;
    }
}