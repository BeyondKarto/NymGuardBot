﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

class Program
{
    private static ITelegramBotClient botClient = new TelegramBotClient("YOUR_API_KEY");
    private static Dictionary<long, int> userAttempts = new Dictionary<long, int>();
    private static Dictionary<long, string> correctAnswers = new Dictionary<long, string>();
    private static Dictionary<long, Timer> activeTimers = new Dictionary<long, Timer>();
    private static Dictionary<long, List<int>> messageIdsToDelete = new Dictionary<long, List<int>>();

    static void Main(string[] args)
    {
        var receiverOptions = new ReceiverOptions
        {
            AllowedUpdates = Array.Empty<UpdateType>() // receive all update types
        };

        botClient.StartReceiving(HandleUpdateAsync, HandleErrorAsync, receiverOptions);

        Console.WriteLine("Bot is running...");
        Console.ReadLine();
    }

    private static async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
    {
        if (update.Type == UpdateType.Message && update.Message != null)
        {
            var message = update.Message;

            if (message.Type == MessageType.ChatMembersAdded)
            {
                foreach (var member in message.NewChatMembers)
                {
                    if (!member.IsBot)
                    {
                        await SendWelcomeMessageAsync(message.Chat.Id, member);
                        await StartQuizAsync(message.Chat.Id, member.Id);
                    }
                }
            }
        }
        else if (update.Type == UpdateType.CallbackQuery && update.CallbackQuery != null)
        {
            await HandleCallbackQueryAsync(update.CallbackQuery);
        }
    }

    private static async Task SendWelcomeMessageAsync(long chatId, User user)
    {
        var welcomeMessage = await botClient.SendTextMessageAsync(
            chatId: chatId,
            text: $"Hello, {user.FirstName}! To verify that you are not a bot, please take a short quiz. You have 30 seconds to choose the correct option."
        );

        if (!messageIdsToDelete.ContainsKey(user.Id))
        {
            messageIdsToDelete[user.Id] = new List<int>();
        }

        messageIdsToDelete[user.Id].Add(welcomeMessage.MessageId);
        Console.WriteLine($"Welcome message sent to user {user.FirstName}");
    }

    private static async Task HandleCallbackQueryAsync(CallbackQuery callbackQuery)
    {
        if (callbackQuery?.Data == null || callbackQuery.Message == null)
        {
            return;
        }

        long userId = callbackQuery.From.Id;
        int userAnswerIndex;

        if (int.TryParse(callbackQuery.Data, out userAnswerIndex))
        {
            // Stop the timer for this user
            if (activeTimers.ContainsKey(userId))
            {
                activeTimers[userId].Change(Timeout.Infinite, Timeout.Infinite);
                activeTimers.Remove(userId);
            }

            if (correctAnswers.TryGetValue(userId, out string correctAnswer))
            {
                string feedbackText;
                bool isCorrect = questions.Any(q => q.Options[userAnswerIndex] == correctAnswer);

                if (isCorrect)
                {
                    feedbackText = "Thank you! You have confirmed that you are not a bot. We wish you good luck in the NYM community, privacy, and freedom of speech!";
                    Console.WriteLine($"User {callbackQuery.From.FirstName} successfully passed the verification.");
                    var feedbackMessage = await botClient.SendTextMessageAsync(
                        chatId: callbackQuery.Message.Chat.Id,
                        text: feedbackText
                    );

                    // Add the feedback message to the list of messages to delete
                    if (!messageIdsToDelete.ContainsKey(userId))
                    {
                        messageIdsToDelete[userId] = new List<int>();
                    }
                    messageIdsToDelete[userId].Add(feedbackMessage.MessageId);

                    await Task.Delay(10000); // Wait 10 seconds
                    await DeleteMessagesAsync(callbackQuery.Message.Chat.Id, userId); // Delete all messages for this user
                }
                else
                {
                    feedbackText = "Incorrect answer! Please try again.";
                    Console.WriteLine($"User {callbackQuery.From.FirstName} answered incorrectly.");
                    var feedbackMessage = await botClient.SendTextMessageAsync(
                        chatId: callbackQuery.Message.Chat.Id,
                        text: feedbackText
                    );

                    // Add the feedback message to the list of messages to delete
                    if (!messageIdsToDelete.ContainsKey(userId))
                    {
                        messageIdsToDelete[userId] = new List<int>();
                    }
                    messageIdsToDelete[userId].Add(feedbackMessage.MessageId);

                    await DeleteMessagesAsync(callbackQuery.Message.Chat.Id, userId); // Delete the previous question
                    await SendQuestionAsync(callbackQuery.Message.Chat.Id, userId); // Send a new question
                }
            }
        }
    }

    private static async Task StartQuizAsync(long chatId, long userId)
    {
        userAttempts[userId] = 0;
        await SendQuestionAsync(chatId, userId);
    }

    private static async Task SendQuestionAsync(long chatId, long userId)
    {
        var question = GetRandomQuestion();
        correctAnswers[userId] = question.CorrectAnswer;

        var inlineKeyboard = new InlineKeyboardMarkup(
            question.Options.Select((option, index) =>
                new[] { InlineKeyboardButton.WithCallbackData(option, index.ToString()) }  // Display options in a column
            ).ToArray()
        );

        var message = await botClient.SendTextMessageAsync(
            chatId: chatId,
            text: $"{question.Text}\nYou have 30 seconds to choose the correct option.",
            replyMarkup: inlineKeyboard
        );

        // Add the message ID to the list of messages to delete
        if (!messageIdsToDelete.ContainsKey(userId))
        {
            messageIdsToDelete[userId] = new List<int>();
        }
        messageIdsToDelete[userId].Add(message.MessageId);
        Console.WriteLine($"Question sent to user {userId}: {question.Text}");

        // Start the timer on the server
        var timer = new Timer(async state => await HandleTimeoutAsync(chatId, userId), null, TimeSpan.FromSeconds(30), Timeout.InfiniteTimeSpan);
        activeTimers[userId] = timer;
    }

    private static async Task HandleTimeoutAsync(long chatId, long userId)
    {
        if (activeTimers.ContainsKey(userId))
        {
            activeTimers[userId].Change(Timeout.Infinite, Timeout.Infinite);
            activeTimers.Remove(userId);
        }

        await DeleteMessagesAsync(chatId, userId);

        userAttempts[userId]++;

        if (userAttempts[userId] >= 3)
        {
            await botClient.BanChatMemberAsync(chatId, userId);
            await botClient.SendTextMessageAsync(
                chatId: chatId,
                text: "The user has been banned for incorrect answers."
            );
            Console.WriteLine($"User with ID {userId} was banned after three incorrect answers.");
        }
        else
        {
            await botClient.SendTextMessageAsync(
                chatId: chatId,
                text: "You did not answer in time! This counts as a failed attempt."
            );
            Console.WriteLine($"User with ID {userId} did not answer in time.");
            await Task.Delay(2000);  // Delay before sending the next question
            await SendQuestionAsync(chatId, userId);
        }
    }

    private static async Task DeleteMessagesAsync(long chatId, long userId)
    {
        if (activeTimers.ContainsKey(userId))
        {
            activeTimers[userId].Change(Timeout.Infinite, Timeout.Infinite);
            activeTimers.Remove(userId);
        }

        if (messageIdsToDelete.ContainsKey(userId) && messageIdsToDelete[userId].Any())
        {
            foreach (var messageId in messageIdsToDelete[userId])
            {
                await botClient.DeleteMessageAsync(chatId, messageId);
            }
            messageIdsToDelete.Remove(userId);
            Console.WriteLine($"Messages for user with ID {userId} were deleted.");
        }
        else
        {
            Console.WriteLine($"Error: No messages found to delete for user with ID {userId}");
        }
    }

    private static Question GetRandomQuestion()
    {
        var random = new Random();
        return questions[random.Next(questions.Count)];
    }

    private static Task HandleErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
    {
        var errorMessage = exception switch
        {
            ApiRequestException apiRequestException => $"Telegram API Error:\n[{apiRequestException.ErrorCode}]\n{apiRequestException.Message}",
            _ => exception.ToString()
        };

        Console.WriteLine(errorMessage);
        return Task.CompletedTask;
    }

    private class Question
    {
        public string Text { get; set; } = string.Empty;  // Initialized as an empty string
        public string[] Options { get; set; } = Array.Empty<string>();  // Initialized as an empty array
        public string CorrectAnswer { get; set; } = string.Empty;  // Initialized as an empty string
    }

    private static readonly List<Question> questions = new List<Question>
    {
        new Question
        {
            Text = "What is the main goal of NYM?",
            Options = new[] { "a) Creating a cryptocurrency wallet", "b) Protecting data privacy", "c) Developing a browser", "d) Selling cloud services" },
            CorrectAnswer = "b) Protecting data privacy"
        },
        new Question
        {
            Text = "What is NYM's main product?",
            Options = new[] { "a) Anonymous social network", "b) Decentralized internet", "c) Mixnet for data protection", "d) Cryptocurrency exchange" },
            CorrectAnswer = "c) Mixnet for data protection"
        },
        new Question
        {
            Text = "What is the role of nodes in the NYM system?",
            Options = new[] { "a) Cryptocurrency mining", "b) Processing and mixing data", "c) Data storage", "d) Smart contract management" },
            CorrectAnswer = "b) Processing and mixing data"
        },
        new Question
        {
            Text = "What does the term 'Mixnet' mean?",
            Options = new[] { "a) Network technology for mixing data", "b) Social media platform", "c) Cryptocurrency mining tool", "d) Big data processing system" },
            CorrectAnswer = "a) Network technology for mixing data"
        },
        new Question
        {
            Text = "What makes NYM different from traditional VPN services?",
            Options = new[] { "a) High connection speed", "b) Decentralized structure", "c) Ease of use", "d) No payment required" },
            CorrectAnswer = "b) Decentralized structure"
        }
    };
}